////Define Everything Here
const DeviceData=[
    
    {
        device_id:"{UUID}",
        bearer_token:"{Token}",
        button_list:[
            {id:"", nickname:""},
        ]
    },
   
];
const APILink="{API Base Url}";

